## Shopware PWA local plugins

In this directory you may develop your Shopware PWA plugins locally.

You'll find here config file with example of local plugin. Just switch flag in `local-plugins.json` to see local plugin in your application.

For instructions about plugins structure and how to develop them please visit https://shopware-pwa-docs.vuestorefront.io/guide/plugins.html