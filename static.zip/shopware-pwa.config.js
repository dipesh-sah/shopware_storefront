module.exports = {
  shopwareEndpoint: "https://shoptest.bay20.in/public",
  shopwareAccessToken: "SWSCEXP3OG0ZZWT2BHRZYTJNEG",
  shopwareDomainsAllowList: ["https://shoptest.bay20.in/public/en", "https://shoptest.bay20.in/public/de"]
};
