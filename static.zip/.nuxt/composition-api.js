import { install } from "vue-demi";

install();
