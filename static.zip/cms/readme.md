## Shopware PWA CMS

In this directory you may override all CMS components from your theme and plugins.

For instructions about CMS structure and how to override specific elements please visit https://shopware-pwa-docs.vuestorefront.io/guide/cms.html
