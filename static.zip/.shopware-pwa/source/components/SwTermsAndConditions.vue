<template>
  <div>This is our Terms and Conditions.</div>
</template>
<script>
export default {
  name: "SwTermsAndConditions",
  setup() {
    return {}
  },
}
</script>
