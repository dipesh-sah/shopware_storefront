<template>
  <div class="nav-container">
    <slot></slot>
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>
  .nav-container {
    z-index: 1;
    position: relative;
  }
</style>
