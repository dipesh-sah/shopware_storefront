<template>
  <div class="sw-product-advertisement"></div>
</template>

<script>
export default {
  name: "SwProductAdvertisement",
  components: {},
}
</script>
